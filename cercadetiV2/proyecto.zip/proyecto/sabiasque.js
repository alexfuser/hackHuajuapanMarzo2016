function sabiasque() {
	var sabias=[];
	sabias[0] = "";
}