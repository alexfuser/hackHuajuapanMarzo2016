@extends('main')
@section('content')
        <div class="content overflow-hidden">
            <div class="row">
                <div class="col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 col-lg-4 col-lg-offset-4">
                    <!-- Register Block -->
                    <div class="block block-themed animated fadeIn">
                        <div class="block-header bg-success">
                            <ul class="block-options">
                                <li>
                                    <a href="#" data-toggle="modal" data-target="#modal-terms">Términos</a>
                                </li>

                            </ul>
                            <h3 class="block-title">Registro</h3>
                        </div>
                        <div class="block-content block-content-full block-content-narrow">

                            <h1 class="h2 font-w600 push-30-t push-5">Bienvenido a la EcoNet</h1>
                            <p>Por favor rellena el siguiente formulario para crear tu nueva cuenta.</p>
                            {{ $erros or 'Default' }}

                            <form class="js-validation-register form-horizontal push-50-t push-50" action="{{ url('/register') }}" method="post">
                                {!! csrf_field() !!}
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <div class="form-material form-material-success">
                                            <input class="form-control" type="text" id="username" name="name" placeholder="Elige un nombre de usuario">
                                            <label for="username">Nombre de Usuario</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <div class="form-material form-material-success">
                                            <input class="form-control" type="email" id="email" name="email" placeholder="Ingresa tu correo electrónico">
                                            <label for="email">Correo electrónico</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <div class="form-material form-material-success">
                                            <input class="form-control" type="password" id="password" name="password" placeholder="Escoge una contraseña...">
                                            <label for="password">Contraseña</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <div class="form-material form-material-success">
                                            <input class="form-control" type="password" id="password2" name="password_confirmation" placeholder="... y ahora confirmalo">
                                            <label for="password2">Confirma tu contraseña</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <label class="css-input switch switch-sm switch-success">
                                            <input type="checkbox" id="terms" name="terms"><span></span> Acepto los términos &amp; condiciones
                                        </label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12 col-sm-6 col-md-5">
                                        <button class="btn btn-block btn-success" type="submit"><i class="fa fa-plus pull-right"></i> Resgístrate</button>
                                    </div>
                                </div>
                            </form>
                            <!-- END Register Form -->
                        </div>
                    </div>
                    <!-- END Register Block -->
                </div>
            </div>
        </div>

@endsection