
<?php $__env->startSection('content'); ?>

        <div id="page-container" class="sidebar-l sidebar-o side-scroll header-navbar-fixed">
            

            <!-- Sidebar -->
            <nav id="sidebar">
                <!-- Sidebar Scroll Container -->
                <div id="sidebar-scroll">
                    <!-- Sidebar Content -->
                    <!-- Adding .sidebar-mini-hide to an element will hide it when the sidebar is in mini mode -->
                    <div class="sidebar-content">
                        <!-- Side Header -->
                        <div class="side-header side-content bg-white-op">
                            <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                            <button class="btn btn-link text-gray pull-right hidden-md hidden-lg" type="button" data-toggle="layout" data-action="sidebar_close">
                                <i class="fa fa-times"></i>
                            </button>
                            
                            <a class="h5 text-white" href="<?php echo e(url('/')); ?>">
                                <i class="fa fa-leaf text-success"></i>
                                <span class="h4 font-w600 sidebar-mini-hide">Econet</span>
                            </a>
                        </div>
                        <!-- END Side Header -->

                        <!-- Side Content -->
                        <div class="side-content">
                            <ul class="nav-main">
                                <li>
                                    <a class="active" href="<?php echo e(url('/')); ?>"><i class="si si-speedometer"></i><span class="sidebar-mini-hide">Panel de Control</span></a>
                                </li>

                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="<?php echo e(url('/perfil')); ?>"><i class="si si-user"></i><span class="sidebar-mini-hide">Mi Perfil</span></a>
                                    <ul>
                                        <li>
                                            <a href="#">Ver</a>
                                        </li>
                                        <li>
                                            <a href="#">Editar</a>
                                        </li>
                                        <li>
                                            <a href="#">Logros</a>
                                        </li>
                                    </ul>
                                </li>

                        
                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="<?php echo e(url('/preguntas')); ?>"><i class="fa fa-question"></i><span class="sidebar-mini-hide">Preguntas</span></a>
                                </li>

                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="<?php echo e(url('/tips')); ?>"><i class="fa fa-lightbulb-o"></i><span class="sidebar-mini-hide">Tips y Sugerencias</span></a>
                                </li>
                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="<?php echo e(url('/distribuidores')); ?>"><i class="fa fa-lightbulb-o"></i><span class="sidebar-mini-hide">Distribuidores</span></a>
                                </li>
                            </ul>
                        </div>
                        <!-- END Side Content -->
                    </div>
                    <!-- Sidebar Content -->
                </div>
                <!-- END Sidebar Scroll Container -->
            </nav>
            <!-- END Sidebar -->

            <!-- Header -->
            <header id="header-navbar" class="content-mini content-mini-full">
                <!-- Header Navigation Right -->
                <ul class="nav-header pull-right">
                    <li>
                        <button class="btn btn-success" data-toggle="modal" data-target="#modal-fadein" type="button">
                            <i class="si si-note fa-1x"></i>
                            Comentar
                        </button>
                    </li>

                    <li>
                        <div class="btn-group">
                            <button class="btn btn-default btn-image dropdown-toggle" data-toggle="dropdown" type="button">
                                <img src="<?php echo e(asset('/img/avatars/avatar10.jpg')); ?>" alt="Avatar">
                                <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-right">
                                <li class="dropdown-header">Perfil</li>
                                <li>
                                    <a tabindex="-1" href="base_pages_inbox.html">
                                        <i class="si si-envelope-open pull-right"></i>
                                        <span class="badge badge-primary pull-right">3</span>Entrada
                                    </a>
                                </li>
                                <li>
                                    <a tabindex="-1" href="base_pages_profile.html">
                                        <i class="si si-user pull-right"></i>
                                        <span class="badge badge-success pull-right">1</span>Perfil
                                    </a>
                                </li>
                                <li>
                                    <a tabindex="-1" href="javascript:void(0)">
                                        <i class="si si-settings pull-right"></i>Configuración
                                    </a>
                                </li>
                                <li class="divider"></li>
                                <li class="dropdown-header">Accones</li>
                                <li>
                                    <a tabindex="-1" href="<?php echo e(url('/logout')); ?>">
                                        <i class="si si-logout pull-right"></i>Cerrar sesión
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    
                </ul>
                <!-- END Header Navigation Right -->

                <!-- Header Navigation Left -->
                <ul class="nav-header pull-left">
                    <li class="hidden-md hidden-lg">
                        <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                        <button class="btn btn-default" data-toggle="layout" data-action="sidebar_toggle" type="button">
                            <i class="fa fa-navicon"></i>
                        </button>
                    </li>
                    <li class="hidden-xs hidden-sm">
                        <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                        <button class="btn btn-default" data-toggle="layout" data-action="sidebar_mini_toggle" type="button">
                            <i class="fa fa-ellipsis-v"></i>
                        </button>
                    </li>
                    <li class="visible-xs">
                        <!-- Toggle class helper (for .js-header-search below), functionality initialized in App() -> uiToggleClass() -->
                        <button class="btn btn-default" data-toggle="class-toggle" data-target=".js-header-search" data-class="header-search-xs-visible" type="button">
                            <i class="fa fa-search"></i>
                        </button>
                    </li>
                    <li class="js-header-search header-search">
                        <form class="form-horizontal" action="base_pages_search.html" method="post">
                            <div class="form-material form-material-primary input-group remove-margin-t remove-margin-b">
                                <input class="form-control" type="text" id="base-material-text" name="base-material-text" placeholder="Search..">
                                <span class="input-group-addon"><i class="si si-magnifier"></i></span>
                            </div>
                        </form>
                    </li>

                </ul>
                <!-- END Header Navigation Left -->
            </header>
            <!-- END Header -->

            <!-- Main Container -->
            <main id="main-container">
                

                <div class="content">
                    <div class="row">
                        <div class="col-lg-12">

                            <!-- PERFIL -->
                            <div class="block">
                                
                                <div class="block-content block-content-full text-center">
                                    <div>
                                        <img class="img-avatar img-avatar96" src="<?php echo e(asset('/img/avatars/avatar2.jpg')); ?>" alt="">
                                    </div>
                                    <div class="h5 push-15-t push-5"><?php echo e($user->name); ?></div>
                                </div>

                                <div class="block-content block-content-mini block-content-full bg-gray-lighter" style="font-size:13px;">
                                    <div class="text-center text-muted">Logros <i class="si si-badge fa-1x" ></i></div>
                                </div>

                                <div class="row items-push text-center">
                                    <div class="col-xs-2">
                                        <div class="push-5"><i class="si si-emoticon-smile fa-1x"></i></div>
                                        <div class="h5 font-w300 text-muted">Medalla de inicio</div>
                                    </div>

                                    <div class="col-xs-2">
                                        <div class="push-5"><i class="si si-diamond fa-1x"></i></div>
                                        <div class="h5 font-w300 text-muted">Usuario experto</div>
                                    </div>
                                    
                                </div>
                            </div>
                            <!-- END PERFIL -->

                            <!-- MURO -->
                            <div class="block">
                                <div class="block-header bg-primary-dark">
                                    <h3 class="block-title" style="color:white">Ultimas publicaciones</h3>
                                </div>

                                <div class="block-content block-content-full" >
                                    <div class="row">
                                        <ul class="list list-timeline pull-t">

                                        <!-- Facebook Notification -->

                                        <?php foreach( $posts as $post): ?>

                                        <!-- Facebook Notification -->
                                        <li>
                                            <div class="list-timeline-time"> <?php echo e($post->updated_at); ?> </div>
                                            <i class="fa fa-comments list-timeline-icon bg-default"></i>
                                            <div class="list-timeline-content">

                                                <p class="font-w600" style="padding-bottom: 10px"> <?php echo e($post->user->name); ?> <strong style="font-size: 20px;"> <?php echo e($post->title); ?> </strong></p>

                                                <?php if( $post->photo != "" ): ?>
                                                    <img class="img-responsive" src="<?php echo e(asset('/uploads/'.$post->photo)); ?>">
                                                <?php endif; ?>

                                                
                                                <p class="font-s13" style="padding-top: 15px; text-align: justify;" > <?php echo e($post->content); ?>

                                                
                                                <div class="row">
                                                    <!-- <a href="#" class="col-xs-3" > 10 <span><i class="si si-drop fa-1x "></i></span></a> -->
                                                    <a href="#" class="col-xs-3  pull-left" > <?php echo e(count( $post->comments )); ?> <span><i class="si si-bubble fa-1x "></i></span></a>    
                                                </div>
                                                <?php if( count( $post->comments ) ): ?>
                                                <button id="showComment<?php echo e($post->id); ?>" style="margin-top: 5px" class="btn-link" onclick="show_coments( <?php echo e($post->id); ?> )"> Ver comentarios </button>
                                                <?php endif; ?>
                                                
                                                <div id="comments<?php echo e($post->id); ?>" class="hidden">
                                                    <?php foreach( $post->comments as $comment ): ?>
                                                    
                                                    <div class="alert-info" style="padding: 15px 5px  1px 5px; margin-bottom: 10px;"> 
                                                        <p><i class="fa fa-info-circle"></i> <strong> <?php echo e($comment->user->name); ?> dijo: </strong> <a class="alert-link" href="javascript:void(0)"> <?php echo e($comment->content); ?> </a>!</p>
                                                    </div>
                                                    
                                                    <?php endforeach; ?>
                                                </div>

                                                </p>
                                                
                                                <div class="col-md-12" style="text-align: right;">
                                                    <button class="btn btn-success" data-toggle="modal" data-target="#modal-fadein2" type="button" onclick="load_id_pub( <?php echo e($post->id); ?> )">
                                                        <i class="si si-note fa-1x"></i>
                                                        Comentar
                                                    </button>
                                                </div>

                                                <script type="text/javascript">
                                                    function load_id_pub( id ) {
                                                        $("#post_id").val( id );
                                                    }

                                                    function show_coments( id ) {

                                                        if( $('#comments' + id).hasClass("hidden") ) {
                                                            $('#comments' + id).removeClass("hidden");
                                                            $('#showComment' + id).html("Ocultar comentarios");
                                                        }
                                                        else {
                                                            $('#comments' + id).addClass("hidden");
                                                            $('#showComment' + id).html("Ver comentarios");
                                                        }
                                                    }
                                                </script>
                                                
                                            </div>
                                        </li>
                                        <!-- END Facebook Notification -->
                                        <?php endforeach; ?>
                                        
                                        <!-- END Facebook Notification -->                                        

                                        </ul>
                                    </div>
                                </div>
                            <!-- END MURO -->
                            
                        </div>
                    </div>
                </div>

                
            </main>
            <!-- END Main Container -->

            <!-- Footer -->
            <footer id="page-footer" class="content-mini content-mini-full font-s12 bg-gray-lighter clearfix">
                <div class="pull-right">
                    Hecho con <i class="fa fa-heart text-city"></i> por <a class="font-w600" href="http://goo.gl/vNS3I" target="_blank">Mictlan Team</a>
                </div>
            </footer>
            <!-- END Footer -->
        </div>
        <!-- END Page Container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-comment'); ?>
        <div class="modal fade" id="modal-fadein" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="block block-themed block-transparent remove-margin-b">
                        <div class="block-header bg-primary-dark">
                            <ul class="block-options">
                                <li>
                                    <button data-dismiss="modal" type="button"><i class="si si-close"></i></button>
                                </li>
                            </ul>
                            <h3 class="block-title">Publicar</h3>
                        </div>
                        <div class="block-content">
                            
                            <div class="block-content block-content-full bg-gray-lighter">
                                <!--  FORM -->
                                <form class="form-horizontal push-10-t" action="<?php echo e(url('/addPost')); ?>" method="post" accept-charset="UTF-8" enctype="multipart/form-data">

                                <?php echo csrf_field(); ?>


                                     <div class="form-group">
                                        <div class="col-md-12">
                                            <div class="form-material">
                                                <select class="form-control" id="tipo" name="type">
                                                    <?php foreach( $postTypes as $postType ): ?>
                                                    <option value="<?php echo e($postType->id); ?>"> <?php echo e($postType->name); ?> </option>        
                                                    <?php endforeach; ?>
                                                </select>   
                                                <label for="tipo">Clasificación</label>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <div class="form-material">
                                                <input class="form-control" id="title" name="title" rows="4"></input>
                                                <label for="title">Título</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <div class="form-material">
                                                <textarea   class="form-control" 
                                                    id="contenido" 
                                                    name="contenido" rows="4"     
                                                    placeholder="Comenta algo..."></textarea>
                                                <label for="contenido">Comentario</label>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <label class="col-xs-12" for="example-file-input">
                                            <button class="btn btn-primary" type="button" onclick="$('#input_img').removeClass('hidden');"><i class="si si-picture fa-1x"></i></button>
                                        </label>
                                    </div>
                                    

                                    <div class="form-group hidden" id="input_img" >
                                        <label class="col-xs-12" for="example-file-input">Agregar Imagen</label>
                                        <div class="col-xs-12">
                                            <input id="img" name="img" type="file">
                                        </div>
                                    </div>
                                   

                                     <div class="form-group">
                                        <button class="btn btn-sm btn-success col-xs-12 pull-right" type="submit" > <i class="fa fa-check"></i> comentar </button>
                                    </div>

                                                                    
                                </form><!-- END FORM -->
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

         <div class="modal fade" id="modal-fadein2" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="block block-themed block-transparent remove-margin-b">
                        <div class="block-header bg-primary-dark">
                            <ul class="block-options">
                                <li>
                                    <button data-dismiss="modal" type="button"><i class="si si-close"></i></button>
                                </li>
                            </ul>
                            <h3 class="block-title">Publicar</h3>
                        </div>
                        <div class="block-content">
                            
                            <div class="block-content block-content-full bg-gray-lighter">
                                <!--  FORM -->
                                <form class="form-horizontal push-10-t" action="<?php echo e(url('/addComment')); ?>" method="post" accept-charset="UTF-8" enctype="multipart/form-data">

                                <?php echo csrf_field(); ?>


                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <div class="form-material">
                                                <textarea   class="form-control" 
                                                    id="contenido" 
                                                    name="contenido" rows="4"     
                                                    placeholder="Comenta algo..."></textarea>
                                                <label for="contenido">Comentario</label>
                                            </div>
                                        </div>
                                    </div>
                                   

                                     <div class="form-group">
                                        <button class="btn btn-sm btn-success col-xs-12 pull-right" type="submit" > <i class="fa fa-check"></i> comentar </button>
                                    </div>

                                    <input type="hidden" value="" id="post_id" name="post_id">
                                                                    
                                </form><!-- END FORM -->
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END Fade In Modal -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>