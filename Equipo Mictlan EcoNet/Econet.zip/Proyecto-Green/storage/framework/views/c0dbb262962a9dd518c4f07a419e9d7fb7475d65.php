
<?php $__env->startSection('content'); ?>

        <div id="page-container" class="sidebar-l sidebar-o side-scroll header-navbar-fixed">


            <!-- Sidebar -->
            <nav id="sidebar">
                <!-- Sidebar Scroll Container -->
                <div id="sidebar-scroll">
                    <!-- Sidebar Content -->
                    <!-- Adding .sidebar-mini-hide to an element will hide it when the sidebar is in mini mode -->
                    <div class="sidebar-content">
                        <!-- Side Header -->
                        <div class="side-header side-content bg-white-op">
                            <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                            <button class="btn btn-link text-gray pull-right hidden-md hidden-lg" type="button" data-toggle="layout" data-action="sidebar_close">
                                <i class="fa fa-times"></i>
                            </button>

                            <a class="h5 text-white" href="<?php echo e(url('/')); ?>">
                                <i class="fa fa-leaf text-success"></i>
                                <span class="h4 font-w600 sidebar-mini-hide">Econet</span>
                            </a>
                        </div>
                        <!-- END Side Header -->

                        <!-- Side Content -->
                        <div class="side-content">
                            <ul class="nav-main">
                                <li>
                                    <a class="active" href="#"><i class="si si-speedometer"></i><span class="sidebar-mini-hide">Panel de Control</span></a>
                                </li>

                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="<?php echo e(url('/perfil')); ?>"><i class="si si-user"></i><span class="sidebar-mini-hide">Mi Perfil</span></a>                                    
                                </li>

                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="http://192.168.43.245:8080/"><i class="fa fa-pagelines"></i><span class="sidebar-mini-hide">Mi invernadero</span></a>
                                </li>

                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="<?php echo e(url('/preguntas')); ?>"><i class="fa fa-question"></i><span class="sidebar-mini-hide">Preguntas</span></a>
                                </li>

                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="<?php echo e(url('/tips')); ?>"><i class="fa fa-lightbulb-o"></i><span class="sidebar-mini-hide">Tips y Sugerencias</span></a>
                                </li>

                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="<?php echo e(url('/distribuidores')); ?>"><i class="fa fa-lightbulb-o"></i><span class="sidebar-mini-hide">Distribuidores</span></a>
                                </li>

                            </ul>
                        </div>
                        <!-- END Side Content -->
                    </div>
                    <!-- Sidebar Content -->
                </div>
                <!-- END Sidebar Scroll Container -->
            </nav>
            <!-- END Sidebar -->

            <!-- Header -->
            <header id="header-navbar" class="content-mini content-mini-full">
                <!-- Header Navigation Right -->
                <ul class="nav-header pull-right">
                    <li>
                        <button class="btn btn-success" data-toggle="modal" data-target="#modal-fadein" type="button">
                            <i class="si si-note fa-1x"></i>
                            Publicar
                        </button>
                    </li>

                    <li>
                      <div class="btn-group">
                          <button class="btn btn-default btn-image dropdown-toggle" data-toggle="dropdown" type="button">
                              <img src="<?php echo e(asset('/img/avatars/avatar10.jpg')); ?>" alt="Avatar">
                              <span class="caret"></span>
                          </button>
                          <ul class="dropdown-menu dropdown-menu-right">
                              <li class="dropdown-header">Perfil</li>
                              <li>
                                  <a tabindex="-1" href="#">
                                      <i class="si si-envelope-open pull-right"></i>
                                      <span class="badge badge-primary pull-right">3</span>Entrada
                                  </a>
                              </li>
                              <li>
                                  <a tabindex="-1" href="#">
                                      <i class="si si-user pull-right"></i>
                                      <span class="badge badge-success pull-right">1</span>Perfil
                                  </a>
                              </li>
                              <li>
                                  <a tabindex="-1" href="#">
                                      <i class="si si-settings pull-right"></i>Configuración
                                  </a>
                              </li>
                              <li class="divider"></li>
                              <li class="dropdown-header">Accones</li>
                              <li>
                                  <a tabindex="-1" href="<?php echo e(url('/logout')); ?>">
                                      <i class="si si-logout pull-right"></i>Cerrar sesión
                                  </a>
                              </li>
                          </ul>
                      </div>
                    </li>

                </ul>
                <!-- END Header Navigation Right -->

                <!-- Header Navigation Left -->
                <ul class="nav-header pull-left">
                    <li class="hidden-md hidden-lg">
                        <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                        <button class="btn btn-default" data-toggle="layout" data-action="sidebar_toggle" type="button">
                            <i class="fa fa-navicon"></i>
                        </button>
                    </li>
                    <li class="hidden-xs hidden-sm">
                        <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                        <button class="btn btn-default" data-toggle="layout" data-action="sidebar_mini_toggle" type="button">
                            <i class="fa fa-ellipsis-v"></i>
                        </button>
                    </li>


                </ul>
                <!-- END Header Navigation Left -->
            </header>
            <!-- END Header -->

            <!-- Main Container -->
            <main id="main-container">


                <div class="content">
                    <div class="row">
                        <div class="<?php if( isset( $question ) ): ?> col-lg-8  col-lg-offset-2 <?php else: ?> col-lg-12 <?php endif; ?>">

                            <!-- MURO -->
                            <?php if( !isset( $questions ) ): ?>
                            <div class="block">
                            <?php endif; ?>


                                <div class="block-content block-content-full" style="padding: 40px;">


                                    <div class="row">
                                        <?php if( isset( $questions ) ): ?>
                                            <?php foreach( $questions as $question ): ?>

                                            <div class="col-sm-6 col-lg-4">
                                                <a href=" <?php echo e(url('/preguntas')); ?>/<?php echo e($question->id); ?> ">
                                                <div class="block block-themed block-rounded">
                                                    <div class="block-header bg-primary">
                                                        <ul class="block-options">
                                                            <li>
                                                                <button type="button"><i class="si si-settings"></i></button>
                                                            </li>
                                                        </ul>
                                                        <h3 class="block-title"> <?php echo e($question->title); ?> </h3>
                                                    </div>
                                                    <div class="block-content">
                                                        <p> <?php echo e($question->content); ?> </p>
                                                        <p> <h6> Por <?php echo e($question->user->name); ?> </h6> </p>
                                                    </div>
                                                </div>
                                                </a>
                                            </div>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <strong style="font-size: 30px;"> <?php echo e($question->title); ?> </strong>

                                            <div class="list-timeline-time" style="margin-top: 20px;"> <strong> Fecha: </strong> <?php echo e($question->updated_at); ?> </div>
                                            <!--<i class="fa fa-comments list-timeline-icon bg-default"></i>-->
                                            <div class="list-timeline-content">

                                                <p class="font-w600" > Realizada por: <?php echo e($question->user->name); ?> </p>


                                                <?php if( $question->photo != "" ): ?>
                                                    <img class="img-responsive" src="<?php echo e(asset('/uploads/'.$question->photo)); ?>">
                                                <?php endif; ?>


                                                <p class="font-s13" style="padding-top: 15px; text-align: justify;" > <?php echo e($question->content); ?>


                                                <div class="row">
                                                    <!-- <a href="#" class="col-xs-3" > 10 <span><i class="si si-drop fa-1x "></i></span></a> -->
                                                    <a href="#" class="col-xs-3  pull-left" > <?php echo e(count( $question->comments )); ?> <span><i class="si si-bubble fa-1x "></i></span></a>
                                                </div>

                                                <button id="showComment<?php echo e($question->id); ?>" style="margin-top: 5px" class="btn-link" onclick="show_coments( <?php echo e($question->id); ?> )"> Comentarios </button>


                                                <div id="comments<?php echo e($question->id); ?>" class="hidden">
                                                    <?php foreach( $question->comments as $comment ): ?>

                                                    <div class="alert-info" style="padding: 15px 5px  1px 5px; margin-bottom: 10px;">
                                                        <p><i class="fa fa-info-circle"></i> <strong> <?php echo e($comment->user->name); ?> dijo: </strong> <a class="alert-link" href="javascript:void(0)"> <?php echo e($comment->content); ?> </a>!</p>
                                                    </div>

                                                    <?php endforeach; ?>
                                                </div>

                                                </p>
                                                <script type="text/javascript">
                                                    function load_id_pub( id ) {
                                                        $("#post_id").val( id );
                                                    }

                                                    function show_coments( id ) {

                                                        if( $('#comments' + id).hasClass("hidden") ) {
                                                            $('#comments' + id).removeClass("hidden");
                                                            $('#showComment' + id).html("Ocultar comentarios");
                                                        }
                                                        else {
                                                            $('#comments' + id).addClass("hidden");
                                                            $('#showComment' + id).html("Ver comentarios");
                                                        }
                                                    }
                                                </script>
                                                <form class="form-horizontal push-10-t" action="<?php echo e(url('/addComment')); ?>" method="post" accept-charset="UTF-8" enctype="multipart/form-data">

                                                    <?php echo csrf_field(); ?>


                                                        <div class="form-group" style="margin: 10%;" >
                                                            <div class="col-md-12">
                                                                <div class="form-material">
                                                                    <textarea   class="form-control"
                                                                        id="contenido"
                                                                        name="contenido" rows="4"
                                                                        placeholder="Comenta algo..."></textarea>
                                                                    <label for="contenido">Comentar</label>
                                                                </div>
                                                            </div>
                                                        </div>


                                                         <div class="form-group">
                                                            <div class="col-md-12">
                                                                <div class="form-material" style="text-align: center;">
                                                                    <button class="btn btn-sm btn-success" type="submit" > <i class="fa fa-check"></i> Comentar </button>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <input type="hidden" value=" <?php echo e($question->id); ?> " id="post_id" name="post_id">

                                                    </form><!-- END FORM -->


                                            </div>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            <?php if( !isset( $questions ) ): ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>


            </main>
            <!-- END Main Container -->

            <!-- Footer -->
            <footer id="page-footer" class="content-mini content-mini-full font-s12 bg-gray-lighter clearfix">
                <div class="pull-right">
                    Crafted with <i class="fa fa-heart text-city"></i> by <a class="font-w600" href="http://goo.gl/vNS3I" target="_blank">pixelcave</a>
                </div>
                <div class="pull-left">
                    <a class="font-w600" href="javascript:void(0)" target="_blank">OneUI 1.0</a> &copy; <span class="js-year-copy"></span>
                </div>
            </footer>
            <!-- END Footer -->
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-comment'); ?>
    <div class="modal fade" id="modal-fadein" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="block block-themed block-transparent remove-margin-b">
                        <div class="block-header bg-primary-dark">
                            <ul class="block-options">
                                <li>
                                    <button data-dismiss="modal" type="button"><i class="si si-close"></i></button>
                                </li>
                            </ul>
                            <h3 class="block-title">Publicar</h3>
                        </div>
                        <div class="block-content">

                            <div class="block-content block-content-full bg-gray-lighter">
                                <!--  FORM -->
                                <form class="form-horizontal push-10-t" action="<?php echo e(url('/addPost')); ?>" method="post" accept-charset="UTF-8" enctype="multipart/form-data">

                                <?php echo csrf_field(); ?>


                                     <div class="form-group">
                                        <div class="col-md-12">
                                            <div class="form-material">
                                                <select class="form-control" id="tipo" name="type">
                                                    <?php foreach( $postTypes as $postType ): ?>
                                                    <option value="<?php echo e($postType->id); ?>"> <?php echo e($postType->name); ?> </option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <label for="tipo">Clasificación</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <div class="form-material">
                                                <input class="form-control" id="title" name="title" rows="4"></input>
                                                <label for="title">Título</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <div class="form-material">
                                                <textarea   class="form-control"
                                                    id="contenido"
                                                    name="contenido" rows="4"
                                                    placeholder="Comenta algo..."></textarea>
                                                <label for="contenido">Comentario</label>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <label class="col-xs-12" for="example-file-input">
                                            <button class="btn btn-primary" type="button" onclick="$('#input_img').removeClass('hidden');"><i class="si si-picture fa-1x"></i></button>
                                        </label>
                                    </div>


                                    <div class="form-group hidden" id="input_img" >
                                        <label class="col-xs-12" for="example-file-input">Agregar Imagen</label>
                                        <div class="col-xs-12">
                                            <input id="img" name="img" type="file">
                                        </div>
                                    </div>


                                     <div class="form-group">
                                        <button class="btn btn-sm btn-success col-xs-12 pull-right" type="submit" > <i class="fa fa-check"></i> comentar </button>
                                    </div>


                                </form><!-- END FORM -->
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
         <div class="modal fade" id="modal-fadein2" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="block block-themed block-transparent remove-margin-b">
                        <div class="block-header bg-primary-dark">
                            <ul class="block-options">
                                <li>
                                    <button data-dismiss="modal" type="button"><i class="si si-close"></i></button>
                                </li>
                            </ul>
                            <h3 class="block-title">Publicar</h3>
                        </div>
                        <div class="block-content">

                            <div class="block-content block-content-full bg-gray-lighter">
                                <!--  FORM -->
                                <form class="form-horizontal push-10-t" action="<?php echo e(url('/addComment')); ?>" method="post" accept-charset="UTF-8" enctype="multipart/form-data">

                                <?php echo csrf_field(); ?>


                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <div class="form-material">
                                                <textarea   class="form-control"
                                                    id="contenido"
                                                    name="contenido" rows="4"
                                                    placeholder="Comenta algo..."></textarea>
                                                <label for="contenido">Comentario</label>
                                            </div>
                                        </div>
                                    </div>


                                     <div class="form-group">
                                        <button class="btn btn-sm btn-success col-xs-12 pull-right" type="submit" > <i class="fa fa-check"></i> comentar </button>
                                    </div>

                                    <input type="hidden" value="" id="post_id" name="post_id">

                                </form><!-- END FORM -->
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>