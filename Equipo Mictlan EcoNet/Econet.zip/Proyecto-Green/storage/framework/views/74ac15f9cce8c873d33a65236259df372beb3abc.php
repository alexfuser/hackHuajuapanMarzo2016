
<?php $__env->startSection('content'); ?>
        <div id="page-container" class="sidebar-l sidebar-o side-scroll header-navbar-fixed">
            
            <div class="content bg-image overflow-hidden" style="background-image: url('assets/img/green.jpg');">
                <div class="push-50-t push-15">
                    <h1 class="h2 text-white animated zoomIn">Dashboard</h1>
                    <h2 class="h5 text-white-op animated zoomIn">Welcome Administrator</h2>
                </div>
            </div>

            <!-- Sidebar -->
            <nav id="sidebar">
                <!-- Sidebar Scroll Container -->
                <div id="sidebar-scroll">
                    <!-- Sidebar Content -->
                    <!-- Adding .sidebar-mini-hide to an element will hide it when the sidebar is in mini mode -->
                    <div class="sidebar-content">
                        <!-- Side Header -->
                        <div class="side-header side-content bg-white-op">
                            <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                            <button class="btn btn-link text-gray pull-right hidden-md hidden-lg" type="button" data-toggle="layout" data-action="sidebar_close">
                                <i class="fa fa-times"></i>
                            </button>
                            
                            <a class="h5 text-white" href="#">
                                <i class="fa fa-leaf text-success"></i>
                                <span class="h4 font-w600 sidebar-mini-hide">Econet</span>
                            </a>
                        </div>
                        <!-- END Side Header -->

                        <!-- Side Content -->
                        <div class="side-content">
                            <ul class="nav-main">
                                <li>
                                    <a class="active" href="index.html"><i class="si si-speedometer"></i><span class="sidebar-mini-hide">Panel de Control</span></a>
                                </li>

                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="#"><i class="si si-user"></i><span class="sidebar-mini-hide">Mi Perfil</span></a>
                                    <ul>
                                        <li>
                                            <a href="#">Ver</a>
                                        </li>
                                        <li>
                                            <a href="#">Editar</a>
                                        </li>
                                        <li>
                                            <a href="#">Logros</a>
                                        </li>
                                    </ul>
                                </li>

                        
                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="#"><i class="fa fa-question"></i><span class="sidebar-mini-hide">Preguntas</span></a>
                                    <ul>
                                        <li>
                                            <a href="#">Ver Todas</a>
                                        </li>
                                        <li>
                                            <a href="#">Categorías</a>
                                        </li>
                                    </ul>
                                </li>

                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="#"><i class="fa fa-lightbulb-o"></i><span class="sidebar-mini-hide">Tips</span></a>
                                    <ul>
                                        <li>
                                            <a href="#">Ver Todas</a>
                                        </li>
                                        <li>
                                            <a href="#">Categorías</a>
                                        </li>
                                    </ul>
                                </li>
                                
                            </ul>
                        </div>
                        <!-- END Side Content -->
                    </div>
                    <!-- Sidebar Content -->
                </div>
                <!-- END Sidebar Scroll Container -->
            </nav>
            <!-- END Sidebar -->

            <!-- Header -->
            <header id="header-navbar" class="content-mini content-mini-full">
                <!-- Header Navigation Right -->
                <ul class="nav-header pull-right">
                    <li>
                        <button class="btn btn-success" data-toggle="modal" data-target="#modal-fadein" type="button">
                            <i class="si si-note fa-1x"></i>
                            Comentar
                        </button>
                    </li>

                    <li>
                        <div class="btn-group">
                            <button class="btn btn-default btn-image dropdown-toggle" data-toggle="dropdown" type="button">
                                <img src="assets/img/avatars/avatar10.jpg" alt="Avatar">
                                <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-right">
                                <li class="dropdown-header">Profile</li>
                                <li>
                                    <a tabindex="-1" href="base_pages_inbox.html">
                                        <i class="si si-envelope-open pull-right"></i>
                                        <span class="badge badge-primary pull-right">3</span>Inbox
                                    </a>
                                </li>
                                <li>
                                    <a tabindex="-1" href="base_pages_profile.html">
                                        <i class="si si-user pull-right"></i>
                                        <span class="badge badge-success pull-right">1</span>Profile
                                    </a>
                                </li>
                                <li>
                                    <a tabindex="-1" href="javascript:void(0)">
                                        <i class="si si-settings pull-right"></i>Settings
                                    </a>
                                </li>
                                <li class="divider"></li>
                                <li class="dropdown-header">Actions</li>
                                <li>
                                    <a tabindex="-1" href="base_pages_lock.html">
                                        <i class="si si-lock pull-right"></i>Lock Account
                                    </a>
                                </li>
                                <li>
                                    <a tabindex="-1" href="base_pages_login.html">
                                        <i class="si si-logout pull-right"></i>Log out
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    
                </ul>
                <!-- END Header Navigation Right -->

                <!-- Header Navigation Left -->
                <ul class="nav-header pull-left">
                    <li class="hidden-md hidden-lg">
                        <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                        <button class="btn btn-default" data-toggle="layout" data-action="sidebar_toggle" type="button">
                            <i class="fa fa-navicon"></i>
                        </button>
                    </li>
                    <li class="hidden-xs hidden-sm">
                        <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                        <button class="btn btn-default" data-toggle="layout" data-action="sidebar_mini_toggle" type="button">
                            <i class="fa fa-ellipsis-v"></i>
                        </button>
                    </li>
                    <li class="visible-xs">
                        <!-- Toggle class helper (for .js-header-search below), functionality initialized in App() -> uiToggleClass() -->
                        <button class="btn btn-default" data-toggle="class-toggle" data-target=".js-header-search" data-class="header-search-xs-visible" type="button">
                            <i class="fa fa-search"></i>
                        </button>
                    </li>
                    <li class="js-header-search header-search">
                        <form class="form-horizontal" action="base_pages_search.html" method="post">
                            <div class="form-material form-material-primary input-group remove-margin-t remove-margin-b">
                                <input class="form-control" type="text" id="base-material-text" name="base-material-text" placeholder="Search..">
                                <span class="input-group-addon"><i class="si si-magnifier"></i></span>
                            </div>
                        </form>
                    </li>

                </ul>
                <!-- END Header Navigation Left -->
            </header>
            <!-- END Header -->

            <!-- Main Container -->
            <main id="main-container">
                

                <div class="content">
                    <div class="row">
                        <div class="col-lg-12">

                            <!-- MURO -->
                            <div class="block">
                                <div class="block-header bg-primary-dark">
                                    <h3 class="block-title" style="color:white">Ultimas publicaciones</h3>
                                </div>

                                <div class="block-content block-content-full" >
                                    <div class="row">
                                        <ul class="list list-timeline pull-t">

                                        <!-- Facebook Notification -->
                                        <li>
                                            <div class="list-timeline-time">13 m</div>
                                            <i class="fa fa-facebook list-timeline-icon bg-default"></i>
                                            <div class="list-timeline-content">
                                                <p class="font-w600">Irvin Castellanos</p>
                                                <p class="font-s13">Aprende a cuidar el medio con nuestra hermosa plataforma ;)</p>
                                            </div>
                                        </li>
                                        <!-- END Facebook Notification -->

                                        <!-- Facebook Notification -->
                                        <li>
                                            <div class="list-timeline-time">23 m</div>
                                            <i class="fa fa-facebook list-timeline-icon bg-default"></i>
                                            <div class="list-timeline-content">
                                                <p class="font-w600">Daniel Hernandez</p>
                                                <p class="font-s13">Bienvenidos a Econet la plataforma que te permite aprender sobre como mejorar nuestras areas verdes
                                                
                                                <div class="row text-left">
                                                    <a href="#" >100 <span><i class="si si-drop fa-1x"></i></span></a>
                                                    <a href="#">12 <span><i class="si si-bubble fa-1x"></i></span></a>    
                                                </div>
                                                
                                                </p>
                                            </div>
                                        </li>
                                        <!-- END Facebook Notification -->

                                        <!-- Facebook Notification -->
                                        <li>
                                            <div class="list-timeline-time">23 m</div>
                                            <i class="fa fa-facebook list-timeline-icon bg-default"></i>
                                            <div class="list-timeline-content">
                                                <p class="font-w600">Daniel Hernandez</p>
                                                <p class="font-s13">Bienvenidos a Econet la plataforma que te permite aprender sobre como mejorar nuestras areas verdes</p>
                                            </div>
                                        </li>
                                        <!-- END Facebook Notification -->

                                        <!-- Facebook Notification -->
                                        <li>
                                            <div class="list-timeline-time">23 m</div>
                                            <i class="fa fa-facebook list-timeline-icon bg-default"></i>
                                            <div class="list-timeline-content">
                                                <p class="font-w600">Daniel Hernandez</p>
                                                <p class="font-s13">Bienvenidos a Econet la plataforma que te permite aprender sobre como mejorar nuestras areas verdes</p>
                                            </div>
                                        </li>
                                        <!-- END Facebook Notification -->


                                        <!-- Facebook Notification -->
                                        <li>
                                            <div class="list-timeline-time">23 m</div>
                                            <i class="fa fa-facebook list-timeline-icon bg-default"></i>
                                            <div class="list-timeline-content">
                                                <p class="font-w600">Daniel Hernandez</p>
                                                <p class="font-s13">Bienvenidos a Econet la plataforma que te permite aprender sobre como mejorar nuestras areas verdes

                                                <div class="row items-push js-gallery">
                                                    <div class="col-sm-6 col-lg-2">
                                                        <a class="img-link" href="assets/img/photos/photo2@2x.jpg">
                                                            <img class="img-responsive" src="assets/img/photos/photo2.jpg" alt="">
                                                        </a>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-2">
                                                        <a class="img-link" href="assets/img/photos/photo2@2x.jpg">
                                                            <img class="img-responsive" src="assets/img/photos/photo2.jpg" alt="">
                                                        </a>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-2">
                                                        <a class="img-link" href="assets/img/photos/photo2@2x.jpg">
                                                            <img class="img-responsive" src="assets/img/photos/photo2.jpg" alt="">
                                                        </a>
                                                    </div>
                                                </div>


                                                </p>
                                            </div>
                                        </li>
                                        <!-- END Facebook Notification -->


                                        <!-- Facebook Notification -->
                                        <li>
                                            <div class="list-timeline-time">23 m</div>
                                            <i class="fa fa-facebook list-timeline-icon bg-default"></i>
                                            <div class="list-timeline-content">
                                                <p class="font-w600">Daniel Hernandez</p>
                                                <p class="font-s13">Bienvenidos a Econet la plataforma que te permite aprender sobre como mejorar nuestras areas verdes</p>
                                            </div>
                                        </li>
                                        <!-- END Facebook Notification -->                                        

                                        </ul>
                                    </div>
                                </div>
                            <!-- END MURO -->
                            
                        </div>
                    </div>
                </div>

                
            </main>
            <!-- END Main Container -->

            <!-- Footer -->
            <footer id="page-footer" class="content-mini content-mini-full font-s12 bg-gray-lighter clearfix">
                <div class="pull-right">
                    Crafted with <i class="fa fa-heart text-city"></i> by <a class="font-w600" href="http://goo.gl/vNS3I" target="_blank">pixelcave</a>
                </div>
                <div class="pull-left">
                    <a class="font-w600" href="javascript:void(0)" target="_blank">OneUI 1.0</a> &copy; <span class="js-year-copy"></span>
                </div>
            </footer>
            <!-- END Footer -->
        </div>
<?php $__env->stopSection(); ?>
        <!-- END Page Container -->

<?php $__env->startSection('modal-coment'); ?>
        <!-- Fade In Modal -->
        <div class="modal fade" id="modal-fadein" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="block block-themed block-transparent remove-margin-b">
                        <div class="block-header bg-primary-dark">
                            <ul class="block-options">
                                <li>
                                    <button data-dismiss="modal" type="button"><i class="si si-close"></i></button>
                                </li>
                            </ul>
                            <h3 class="block-title">Publicar</h3>
                        </div>
                        <div class="block-content">
                            
                            <div class="block-content block-content-full bg-gray-lighter">
                                <!--  FORM -->
                                <form class="form-horizontal push-10-t" action="base_forms_elements_modern.html" method="post" onsubmit="return false;">

                                     <div class="form-group">
                                        <div class="col-md-12">
                                            <div class="form-material">
                                                <select class="form-control" id="tipo" name="tipo">
                                                    <option value="1">Pubicación</option>        
                                                    <option value="1">Pregunta</option>        
                                                    <option value="1">Tip</option>        
                                                </select>   
                                                <label for="tipo">Clasificación</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-xs-12" for="example-file-input">
                                            <button class="btn btn-primary" onclick="$('#input_img').removeClass('hidden');"><i class="si si-picture fa-1x"></i></button>
                                        </label>
                                    </div>
                                    

                                    <div class="form-group hidden" id="input_img" >
                                        <label class="col-xs-12" for="example-file-input">Agregar Imagen</label>
                                        <div class="col-xs-12">
                                            <input id="example-file-input" name="example-file-input" type="file">
                                        </div>
                                    </div>
                                   
                                    

                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <div class="form-material">
                                                <textarea   class="form-control" 
                                                    id="material-textarea-large" 
                                                    name="material-textarea-large" rows="4"     
                                                    placeholder="Please add a comment">
                                                </textarea>
                                                <label for="material-textarea-large">Cuerpo</label>
                                            </div>
                                        </div>
                                    </div>

                                                        
                                </form><!-- END FORM -->
                            </div>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-default" type="button" data-dismiss="modal">Close</button>
                        <button class="btn btn-sm btn-success" type="button" data-dismiss="modal"><i class="fa fa-check"></i> Ok</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- END Fade In Modal -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>