<?php $__env->startSection('content'); ?>

        <div id="page-container" class="sidebar-l sidebar-o side-scroll header-navbar-fixed">


            <!-- Sidebar -->
            <nav id="sidebar">
                <!-- Sidebar Scroll Container -->
                <div id="sidebar-scroll">
                    <!-- Sidebar Content -->
                    <!-- Adding .sidebar-mini-hide to an element will hide it when the sidebar is in mini mode -->
                    <div class="sidebar-content">
                        <!-- Side Header -->
                        <div class="side-header side-content bg-white-op">
                            <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                            <button class="btn btn-link text-gray pull-right hidden-md hidden-lg" type="button" data-toggle="layout" data-action="sidebar_close">
                                <i class="fa fa-times"></i>
                            </button>

                            <a class="h5 text-white" href="<?php echo e(url('/')); ?>">
                                <i class="fa fa-leaf text-success"></i>
                                <span class="h4 font-w600 sidebar-mini-hide">Econet</span>
                            </a>
                        </div>
                        <!-- END Side Header -->

                        <!-- Side Content -->
                        <div class="side-content">
                            <ul class="nav-main">
                                <li>
                                    <a class="active" href="#"><i class="si si-speedometer"></i><span class="sidebar-mini-hide">Panel de Control</span></a>
                                </li>

                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="<?php echo e(url('/perfil')); ?>"><i class="si si-user"></i><span class="sidebar-mini-hide">Mi Perfil</span></a>
                                    
                                </li>

                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="http://192.168.43.245:8080/"><i class="fa fa-pagelines"></i><span class="sidebar-mini-hide">Mi invernadero</span></a>
                                </li>

                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="<?php echo e(url('/preguntas')); ?>"><i class="fa fa-question"></i><span class="sidebar-mini-hide">Preguntas</span></a>
                                </li>

                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="<?php echo e(url('/tips')); ?>"><i class="fa fa-lightbulb-o"></i><span class="sidebar-mini-hide">Tips y Sugerencias</span></a>
                                </li>

                                <li>
                                    <a class="nav-submenu" data-toggle="nav-submenu" href="<?php echo e(url('/distribuidores')); ?>"><i class="fa fa-lightbulb-o"></i><span class="sidebar-mini-hide">Distribuidores</span></a>
                                </li>

                            </ul>
                        </div>
                        <!-- END Side Content -->
                    </div>
                    <!-- Sidebar Content -->
                </div>
                <!-- END Sidebar Scroll Container -->
            </nav>
            <!-- END Sidebar -->

            <!-- Header -->
            <header id="header-navbar" class="content-mini content-mini-full">
                <!-- Header Navigation Right -->
                <ul class="nav-header pull-right">
                    <li>
                        <button class="btn btn-success" data-toggle="modal" data-target="#modal-fadein" type="button">
                            <i class="si si-note fa-1x"></i>
                            Publicar
                        </button>
                    </li>

                    <li>
                      <div class="btn-group">
                          <button class="btn btn-default btn-image dropdown-toggle" data-toggle="dropdown" type="button">
                              <img src="<?php echo e(asset('/img/avatars/avatar10.jpg')); ?>" alt="Avatar">
                              <span class="caret"></span>
                          </button>
                          <ul class="dropdown-menu dropdown-menu-right">
                              <li class="dropdown-header">Perfil</li>
                              <li>
                                  <a tabindex="-1" href="#">
                                      <i class="si si-envelope-open pull-right"></i>
                                      <span class="badge badge-primary pull-right">3</span>Entrada
                                  </a>
                              </li>
                              <li>
                                  <a tabindex="-1" href="#">
                                      <i class="si si-user pull-right"></i>
                                      <span class="badge badge-success pull-right">1</span>Perfil
                                  </a>
                              </li>
                              <li>
                                  <a tabindex="-1" href="#">
                                      <i class="si si-settings pull-right"></i>Configuración
                                  </a>
                              </li>
                              <li class="divider"></li>
                              <li class="dropdown-header">Accones</li>
                              <li>
                                  <a tabindex="-1" href="<?php echo e(url('/logout')); ?>">
                                      <i class="si si-logout pull-right"></i>Cerrar sesión
                                  </a>
                              </li>
                          </ul>
                      </div>
                    </li>

                </ul>
                <!-- END Header Navigation Right -->

                <!-- Header Navigation Left -->
                <ul class="nav-header pull-left">
                    <li class="hidden-md hidden-lg">
                        <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                        <button class="btn btn-default" data-toggle="layout" data-action="sidebar_toggle" type="button">
                            <i class="fa fa-navicon"></i>
                        </button>
                    </li>
                    <li class="hidden-xs hidden-sm">
                        <!-- Layout API, functionality initialized in App() -> uiLayoutApi() -->
                        <button class="btn btn-default" data-toggle="layout" data-action="sidebar_mini_toggle" type="button">
                            <i class="fa fa-ellipsis-v"></i>
                        </button>
                    </li>


                </ul>
                <!-- END Header Navigation Left -->
            </header>
            <!-- END Header -->

            <!-- Main Container -->
            <main id="main-container">


                <div class="content">
                    <div class="row">
                        <div class="<?php if( isset( $question ) ): ?> col-lg-8  col-lg-offset-2 <?php else: ?> col-lg-12 <?php endif; ?>">

                            <!-- MURO -->



                                <div class="block-content block-content-full" style="padding: 40px;">


                                    <div class="row">

                                            <a href="#">
                                            <div class="col-sm-6 col-lg-4">
                                                <div class="block block-themed block-rounded">
                                                    <div class="block-header bg-primary">
                                                        <ul class="block-options">
                                                            <li>
                                                                <button type="button"><i class="si si-settings"></i></button>
                                                            </li>
                                                        </ul>
                                                        <h3 class="block-title"> Hortalizas y Legumbres "El Granjero" </h3>
                                                    </div>
                                                    <div class="block-content">
                                                        <p> Venta y de semillas y retoños de todo tipo. </p>

                                                    </div>
                                                </div>
                                            </div>
                                            </a>
                                            <a href="#">
                                            <div class="col-sm-6 col-lg-4">
                                                <div class="block block-themed block-rounded">
                                                    <div class="block-header bg-primary">
                                                        <ul class="block-options">
                                                            <li>
                                                                <button type="button"><i class="si si-settings"></i></button>
                                                            </li>
                                                        </ul>
                                                        <h3 class="block-title"> Hortalizas y Legumbres "El Granjero" </h3>
                                                    </div>
                                                    <div class="block-content">
                                                        <p> Venta y de semillas y retoños de todo tipo. </p>

                                                    </div>
                                                </div>
                                            </div>
                                            </a>
                                            <a href="#">
                                            <div class="col-sm-6 col-lg-4">
                                                <div class="block block-themed block-rounded">
                                                    <div class="block-header bg-primary">
                                                        <ul class="block-options">
                                                            <li>
                                                                <button type="button"><i class="si si-settings"></i></button>
                                                            </li>
                                                        </ul>
                                                        <h3 class="block-title"> Hortalizas y Legumbres "El Granjero" </h3>
                                                    </div>
                                                    <div class="block-content">
                                                        <p> Venta y de semillas y retoños de todo tipo. </p>

                                                    </div>
                                                </div>
                                            </div>
                                            </a>
                                            <a href="#">
                                            <div class="col-sm-6 col-lg-4">
                                                <div class="block block-themed block-rounded">
                                                    <div class="block-header bg-primary">
                                                        <ul class="block-options">
                                                            <li>
                                                                <button type="button"><i class="si si-settings"></i></button>
                                                            </li>
                                                        </ul>
                                                        <h3 class="block-title"> Hortalizas y Legumbres "El Granjero" </h3>
                                                    </div>
                                                    <div class="block-content">
                                                        <p> Venta y de semillas y retoños de todo tipo. </p>

                                                    </div>
                                                </div>
                                            </div>
                                            </a>
                                            <a href="#">
                                            <div class="col-sm-6 col-lg-4">
                                                <div class="block block-themed block-rounded">
                                                    <div class="block-header bg-primary">
                                                        <ul class="block-options">
                                                            <li>
                                                                <button type="button"><i class="si si-settings"></i></button>
                                                            </li>
                                                        </ul>
                                                        <h3 class="block-title"> Hortalizas y Legumbres "El Granjero" </h3>
                                                    </div>
                                                    <div class="block-content">
                                                        <p> Venta y de semillas y retoños de todo tipo. </p>

                                                    </div>
                                                </div>
                                            </div>
                                            </a>

                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <!-- Map Markers Map -->
                                            <div class="block">
                                                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d2764.4614054502213!2d-97.80682871050328!3d17.8272936372748!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1ses-419!2smx!4v1449418957655" width="100%" height="460" frameborder="0" style="border:0" allowfullscreen></iframe>
                                            </div>
                                            <!-- END Map Markers Map -->
                                        </div>
                                    </div>

                                </div>

                        </div>
                    </div>
                </div>


            </main>
            <!-- END Main Container -->

            <!-- Footer -->
            <footer id="page-footer" class="content-mini content-mini-full font-s12 bg-gray-lighter clearfix">
                <div class="pull-right">
                    Hecho con <i class="fa fa-heart text-city"></i> por <a class="font-w600" href="http://goo.gl/vNS3I" target="_blank">Mictlan Team</a>
                </div>
            </footer>
            <!-- END Footer -->
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal-comment'); ?>
    <div class="modal fade" id="modal-fadein" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="block block-themed block-transparent remove-margin-b">
                        <div class="block-header bg-primary-dark">
                            <ul class="block-options">
                                <li>
                                    <button data-dismiss="modal" type="button"><i class="si si-close"></i></button>
                                </li>
                            </ul>
                            <h3 class="block-title">Publicar</h3>
                        </div>
                        <div class="block-content">

                            <div class="block-content block-content-full bg-gray-lighter">
                                <!--  FORM -->
                                <form class="form-horizontal push-10-t" action="<?php echo e(url('/addPost')); ?>" method="post" accept-charset="UTF-8" enctype="multipart/form-data">

                                <?php echo csrf_field(); ?>


                                     <div class="form-group">
                                        <div class="col-md-12">
                                            <div class="form-material">
                                                <select class="form-control" id="tipo" name="type">

                                                    <option value="1"> Pregunta </option>
                                                    <option value="2"> Tip </option>
                                                    <option value="3"> Sugerencia </option>

                                                </select>
                                                <label for="tipo">Clasificación</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <div class="form-material">
                                                <input class="form-control" id="title" name="title" rows="4"></input>
                                                <label for="title">Título</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <div class="form-material">
                                                <textarea   class="form-control"
                                                    id="contenido"
                                                    name="contenido" rows="4"
                                                    placeholder="Comenta algo..."></textarea>
                                                <label for="contenido">Comentario</label>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <label class="col-xs-12" for="example-file-input">
                                            <button class="btn btn-primary" type="button" onclick="$('#input_img').removeClass('hidden');"><i class="si si-picture fa-1x"></i></button>
                                        </label>
                                    </div>


                                    <div class="form-group hidden" id="input_img" >
                                        <label class="col-xs-12" for="example-file-input">Agregar Imagen</label>
                                        <div class="col-xs-12">
                                            <input id="img" name="img" type="file">
                                        </div>
                                    </div>


                                     <div class="form-group">
                                        <button class="btn btn-sm btn-success col-xs-12 pull-right" type="submit" > <i class="fa fa-check"></i> comentar </button>
                                    </div>


                                </form><!-- END FORM -->
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
         <div class="modal fade" id="modal-fadein2" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="block block-themed block-transparent remove-margin-b">
                        <div class="block-header bg-primary-dark">
                            <ul class="block-options">
                                <li>
                                    <button data-dismiss="modal" type="button"><i class="si si-close"></i></button>
                                </li>
                            </ul>
                            <h3 class="block-title">Publicar</h3>
                        </div>
                        <div class="block-content">

                            <div class="block-content block-content-full bg-gray-lighter">
                                <!--  FORM -->
                                <form class="form-horizontal push-10-t" action="<?php echo e(url('/addComment')); ?>" method="post" accept-charset="UTF-8" enctype="multipart/form-data">

                                <?php echo csrf_field(); ?>


                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <div class="form-material">
                                                <textarea   class="form-control"
                                                    id="contenido"
                                                    name="contenido" rows="4"
                                                    placeholder="Comenta algo..."></textarea>
                                                <label for="contenido">Comentario</label>
                                            </div>
                                        </div>
                                    </div>


                                     <div class="form-group">
                                        <button class="btn btn-sm btn-success col-xs-12 pull-right" type="submit" > <i class="fa fa-check"></i> comentar </button>
                                    </div>

                                    <input type="hidden" value="" id="post_id" name="post_id">

                                </form><!-- END FORM -->
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>