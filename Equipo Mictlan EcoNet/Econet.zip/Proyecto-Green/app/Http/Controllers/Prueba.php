<?php

namespace App\Http\Controllers;

use App\Post;
use App\User;
use App\Comment;

use Illuminate\Http\Request;

use App\Http\Requests;

class Prueba extends Controller
{

    public function index() {

    	//return Post::all();
    	//return User::find(1)->posts;
    	//return Post::find(4)->user;

    	/*
    	return Post::create([
            'content' => "post 4",
            'user_id' => 2,
        ]);
        //*/

        /*
    	return Comment::create([
            'content' => "comment 2",
            'user_id' => 1,
            'post_id' => 1,
        ]);
        //*/

        //return Comment::find(1)->post;
        //return Post::orderBy('updated_at', 'desc')->take(4)->get();

    }
}
