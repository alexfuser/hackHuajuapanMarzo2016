<?php

namespace App\Http\Controllers;

use App\Post;
use App\User;
use App\Comment;
use App\PostType;

use App\Http\Requests;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home')->with('posts', Post::orderBy('updated_at', 'desc')->take(10)->get() )
            ->with('postTypes', PostType::all() );
    }
}
