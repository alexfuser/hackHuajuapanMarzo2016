<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Post;
use App\PostType;

class QuestionController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
    }

    public function index() {

    	return view('questions')
    		->with('questions', Post::where('type', 1)->take(10)->get() )
    		->with('postTypes', PostType::all() );
    }

    public function showQuestion( $id ) {

    	return view('questions')
    		->with('question', Post::where('id', $id)->first() )
    		->with('postTypes', PostType::all() );
    }

}
