<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use Auth;
use App\Post;
use App\Comment;
use App\PostType;

class UserController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
    }

    public function index() {
    	return view('perfil')
    		->with('user', Auth::user() )
    		->with('posts', Post::where('user_id', Auth::user()->id )->orderBy('updated_at', 'desc')->get() )
    		->with('comments', Comment::where('user_id', Auth::user()->id) )
    		->with('postTypes', PostType::all() );
    }
}
