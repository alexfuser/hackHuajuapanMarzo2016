<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Comment;

use App\Http\Requests;

class CommentController extends Controller
{

	public function __construct() {
        $this->middleware('auth');
    }
    
    public function create( Request $request ) {

    	Comment::create([
    		
    		'content'	=> $request->input('contenido'),
    		'user_id'	=> Auth::user()->id,
    		'post_id'	=> $request->input('post_id'),
    		
    	]);


    	return back();

    }
}
