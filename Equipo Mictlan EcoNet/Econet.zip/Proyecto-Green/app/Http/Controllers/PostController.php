<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Post;
use Auth;

use App\Http\Requests;

class PostController extends Controller
{

	public function __construct() {
        $this->middleware('auth');
    }

    public function create( Request $request ) {


    	if( $request->file("img") != null ){

    		$img = $request->file("img");
    		$random = rand(1,100000);
    		$img->move('uploads', $random.$img->getClientOriginalName() );	
    	
    	}
    	


    	Post::create([
    		'photo'		=> $request->file("img") != null ? $random.$img->getClientOriginalName() : "",
    		'title'		=> $request->input('title'),
    		'content'	=> $request->input('contenido'),
    		'user_id'	=> Auth::user()->id,
    		'type'		=> $request->input('type')
    		
    	]);


    	return back();

    }
}
