<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Post;
use App\PostType;

class TipController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
    }

    public function index() {

    	return view('questions')
    		->with('questions', Post::whereRaw('type = ? or type = ?', [2,3])->take(10)->get() )
    		->with('postTypes', PostType::all() );
    }

    public function showQuestion( $id ) {

    	return view('questions')
    		->with('question', Post::where('id', $id)->first() )
    		->with('postTypes', PostType::all() );
    }
}
