$(document).ready(function () {
//----------------------------------------//
//---------------Iniciar Sesión-----------//
//----------------------------------------//
//----------------------------------------//
$('#formulario').submit(function( event ){
var username=$("#usuario").val();
var password=$("#password").val();
var dataString = 'usuario='+username+'&password='+password+'&iniciar_sesion=';
if($.trim(username).length>0 && $.trim(password).length>0){
        $.ajax({
            type: "POST",
            url: "http://ittogo.emgear.com.mx/controlador/controlador.php",
            data: dataString,
            cache: false,
            success: function(data){
            if(data==1) {
                activate_page("#login_page"); 
            }
                    else if(data==2){
                    navigator.notification.vibrate(1000);
                    navigator.notification.alert("El usuario no existe",1,"Error de inicio","Aceptar");  
                    }
                        else{
                    navigator.notification.vibrate(1000);
                    navigator.notification.alert("Contraseña no valida",1,"Error de inicio","Aceptar");
                        }
            }
        });
}
return false;
});
//----------------------------------------//
//---------------REGISTRAR USUARIO--------//
//----------------------------------------//
//----------------------------------------//
$('#registrar').submit(function( event ){
var nombre=$("#newuser_nombre").val();
var email=$("#newuser_usuario").val();
var celular=$("#newuser_celular").val();
var password=$("#newuser_password").val();
var password1=$("#newuser_password1").val();
var datos = 'usuario='+email+'&password='+password+'&celular='+celular+'&nombre='+nombre+
'&alta_usuario=';
    $.ajax({
        type        : "POST",
        cache       : false,
        url: "http://ittogo.emgear.com.mx/controlador/controlador.php",
        data        : datos,
        cache: false,
       
	   success: function(data) {
            if(data==1){
               navigator.notification.vibrate(1000);
               navigator.notification.alert("Registrado Correctamente",1,"Registro","Aceptar");
               activate_page("#control")
            }
            else if(data==2){
                navigator.notification.vibrate(1000);
                navigator.notification.alert("Ocurrio un error intentalo nuevamente",1,"Error","Aceptar")
            }
            else{
                navigator.notification.vibrate(1000);
                navigator.notification.alert("Error desconocido",1,"Error","Aceptar")
            }
       }
    });

    return false;
});
    
    
    
    
});